
              <!--file location: app/modules/add_funds/views/index.php-->

              <!--walletmaxpay Header Coding-->
              <?php
                 if(isset($_GET['success'])){
                      $DB_HOST = constant("DB_HOST");
                      $DB_USER = constant("DB_USER");
                      $DB_PASS = constant("DB_PASS");
                      $DB_NAME = constant("DB_NAME");
                      
                      $sqlconn=mysqli_connect($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
                      
                      $users = session('user_current_info');
                      $user_idssss = $users['email'];

                      $transactionId = $_GET['transactionId'];
                      $paymentAmount = $_GET['paymentAmount'];
                      $paymentFee = $_GET['paymentFee'];
                      
                      $amount_session = $_SESSION['amont_session'];

                      $transaction_id_walletmaxpay = $transactionId;

                      $curl = curl_init();
                      curl_setopt_array($curl, array(
                      CURLOPT_URL => 'https://pay.walletmaxpay.com/verify.php',
                      CURLOPT_RETURNTRANSFER => true,
                      CURLOPT_ENCODING => '',
                      CURLOPT_MAXREDIRS => 10,
                      CURLOPT_TIMEOUT => 0,
                      CURLOPT_FOLLOWLOCATION => true,
                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                      CURLOPT_CUSTOMREQUEST => 'POST',
                      CURLOPT_POSTFIELDS => array('transaction_id' => $transaction_id_walletmaxpay),
                      ));
                      $response = curl_exec($curl);
                      curl_close($curl);
                      
                      if($response == 1){
                          $sql = "UPDATE general_users SET `balance`=`balance`+$amount_session WHERE email='$user_idssss'";
                          if(mysqli_query($sqlconn,$sql)){
                            unset($_SESSION["amont_session"]);
              ?>
                              <script>
                                  location.href="<?=BASE?>add_funds";
                              </script>
              <?php
                          }
                      }else{
                          echo "Failed. Id Not Match";
                      }
                 }
              ?>
              <!--walletmaxpay Header Coding-->


              <!--walletmaxpay Button Coding-->
              <?php
              if (get_option("is_active_walletmaxpay")) {
              ?>
              <li class="m-t-10">
                <a data-toggle="tab" href="#walletmaxpay_gateway"><i class="fa fa-hand-o-right"></i> <?=lang("walletmaxpay_gateway")?></a>
              </li>
              <?php }?>
              <!--walletmaxpay Button Coding-->


              <!--walletmaxpay card-body Coding-->
              <?php
                if (get_option("is_active_walletmaxpay")) {
                   $users = session('user_current_info');
                   
                    if(isset($_GET['payment_method'])){
                        $payment_method = $_GET['payment_method'];
                        $amount = $_GET['amount'];
                        
                        if($amount+0.1 > get_option("payment_transaction_min")){
                            $_SESSION["amont_session"] = $amount;
                            $amount = $amount*get_option("walletmaxpay_currency_rate");
                            
                            $apikey = get_option("walletmaxpay_api_key"); //Your Api Key
                            $clientkey = get_option("walletmaxpay_client_key"); //Your Client Key
                            $secretkey = get_option("walletmaxpay_secret_key"); //Your Secret Key
                        
                            $cus_name = $users['first_name'].' '.$users['last_name'];
                            $cus_email = $users['email'];
                        
                            //success url
                            $success_url = BASE.'add_funds?success='.$users['email'];
                            //cancel url
                            $cancel_url = BASE.'add_funds';
                            $hostname = get_option("walletmaxpay_host_name");
                        
                            $curl = curl_init();
                            curl_setopt_array($curl, array(
                            CURLOPT_URL => 'https://pay.walletmaxpay.com/checkout.php',
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_ENCODING => '',
                            CURLOPT_MAXREDIRS => 10,
                            CURLOPT_TIMEOUT => 0,
                            CURLOPT_FOLLOWLOCATION => true,
                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                            CURLOPT_CUSTOMREQUEST => 'POST',
                            CURLOPT_POSTFIELDS => array('api' => $apikey,'client' => $clientkey,'secret' => $secretkey,'amount' => $amount,'position' => $hostname,'success_url' => $success_url,'cancel_url' => $cancel_url,'cus_name' => $cus_name,'cus_email' => $cus_email),
                            ));
                            $response = curl_exec($curl);
                            curl_close($curl);
                            echo $response;
                        }else{
              ?>
                           <script>
                               location.href="<?=BASE?>add_funds";
                           </script>
              <?php
                        }
                    }
              ?>
              
                    <div id="walletmaxpay_gateway" class="tab-pane fade show">
                      <form class="" action=""  method="GET">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="for-group text-center">
                              <img src="https://walletmaxpay.com/assets/img/logo_sites.png" alt="2checkout icon">
                              <p class="p-t-10"><small><?=sprintf(lang("you_can_deposit_funds_with_Bkash_NAGAD_Rocket_Upay_via_walletmaxpay_gateway"), 'walletmaxpay')?></small></p>
                            </div>
                    
                            <div class="form-group">
                              <label><?=sprintf(lang("amount_usd"), 'USD')?></label>
                              <input class="form-control square" type="number" name="amount" placeholder="1"required min="<?php echo get_option("payment_transaction_min")?>">
                              <input type="hidden" name="payment_method" value="walletmaxpay">
                            </div>

                            <br>
                            
                            <div class="form-group">
                              <label class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" name="agree" value="1"required>
                                <span class="custom-control-label"><?=lang("yes_i_understand_after_the_funds_added_i_will_not_ask_fraudulent_dispute_or_chargeback")?></span>
                              </label>
                            </div>
                            
                            <div class="form-actions left">
                              <button type="submit" class="btn round btn-primary btn-min-width mr-1 mb-1">
                                <?=lang("Pay")?>
                              </button>
                            </div>
                    
                          </div>  
                        </div>
                      </form>
                    </div>
              <?php }?>
              <!--walletmaxpay card-body Coding-->
