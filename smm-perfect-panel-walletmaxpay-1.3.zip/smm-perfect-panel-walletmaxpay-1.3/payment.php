
              <!--file location: app/modules/setting/views/payment.php-->

              <!--walletmaxpay Coding-->
              <h5 class="text-info"><i class="fe fe-link"></i> <?=lang("walletmaxpay_gateway")?></h5>
              
              <div class="form-group">
                <label class="form-label"><?=lang("walletmaxpay_api_key")?></label>
                <input class="form-control" name="walletmaxpay_api_key" value="<?=get_option('walletmaxpay_api_key',"")?>">
              </div> 
              <div class="form-group">
                <label class="form-label"><?=lang("walletmaxpay_client_key")?></label>
                <input class="form-control" name="walletmaxpay_client_key" value="<?=get_option('walletmaxpay_client_key',"")?>">
              </div> 
              <div class="form-group">
                <label class="form-label"><?=lang("walletmaxpay_secret_key")?></label>
                <input class="form-control" name="walletmaxpay_secret_key" value="<?=get_option('walletmaxpay_secret_key',"")?>">
              </div> 
              <div class="form-group">
                <label class="form-label"><?=lang("walletmaxpay_host_name")?></label>
                <input class="form-control" name="walletmaxpay_host_name" value="<?=get_option('walletmaxpay_host_name',"")?>">
              </div> 
              <div class="form-group">
                <label class="form-label"><?=lang("walletmaxpay_currency_rate")?></label>
                <input class="form-control" name="walletmaxpay_currency_rate" value="<?=get_option('walletmaxpay_currency_rate',"")?>">
              </div> 
              
              <div class="form-group">
                <div class="form-label"><?=lang("Status")?></div>
                <div class="custom-controls-stacked">
                  <label class="custom-control custom-checkbox">
                    <input type="hidden" name="is_active_walletmaxpay" value="0">
                    <input type="checkbox" class="custom-control-input" name="is_active_walletmaxpay" value="1" <?=(get_option('is_active_walletmaxpay', "") == 1)? "checked" : ''?>>
                    <span class="custom-control-label"><?=lang("Active")?></span>
                  </label>
                </div>
              </div>
              <!--walletmaxpay Coding-->
